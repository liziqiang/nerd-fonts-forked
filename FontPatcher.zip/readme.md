
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit f25aa13bbac2be2402b7d95c09c41bbf9c26e190
        Author: allcontributors[bot] <46447321+allcontributors[bot]@users.noreply.github.com>
        Date:   Wed Jan 10 10:30:16 2024 +0000
        
            docs: update .all-contributorsrc
