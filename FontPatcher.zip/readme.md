
# Nerd Fonts

This is font-patcher python script (and required source files) from a Nerd Fonts release.

## Running

* To execute run: `fontforge --script ./font-patcher --complete <YOUR FONT FILE>`
* For more CLI options and help: `fontforge --script ./font-patcher --help`

## Further info

For more information see:
* https://github.com/ryanoasis/nerd-fonts/
* https://github.com/ryanoasis/nerd-fonts/releases/latest/

## Version
This archive is created from

        commit bc044d1df0b756db70879649d4e504eb8a9fefce
        Author: Fini Jastrow <ulf.fini.jastrow@desy.de>
        Date:   Tue Oct 8 12:41:36 2024 +0200
        
            CascadiaCode: Mention upstream's NF version
            
            Fixes: #1622
            
            Signed-off-by: Fini Jastrow <ulf.fini.jastrow@desy.de>
