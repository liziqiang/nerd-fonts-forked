# Devicons

For more information have a look at the upstream website: https://github.com/vorillaz/devicons

This is taken directly from the repository default branch, which is ahead of release 1.8.0.
We call it 1.8.1 here, but there is no such release.

## Source bugs fixed

Glyph 0xE6B6 is defective in the original font. We hand optimized and fixed that.

Version: 1.8.1
