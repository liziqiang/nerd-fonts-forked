### Contents

This directory contains all the glyphs (glyph sets) that the `font-patcher` puts into the fonts.

If a icon font here is updated, do not forget to update the database file in `bin/script/libs`.

The 'Seti and Original' icons (in `original-source.otf`) is automatically generated from the glyphs in `src/svgs`.
Do not edit and commit changes to that font directly.
