# Pomicons

For more information have a look at the upstream website: https://github.com/gabrielelana/pomicons

Version: 1.001
